# ROS Driver for E-Puck Robot
This is a fork of this [repo](https://github.com/verlab-ros-pkg/epuck_driver).
It is extended to support all the e-puck sensors.

This driver is maintained by [GCtronic](http://www.gctronic.com/).

## How to use
For detailed informations about the driver refer to the [e-puck ROS wiki](http://www.gctronic.com/doc/index.php/E-Puck#ROS).

